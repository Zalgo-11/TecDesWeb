package com.ipn.mx.escuela;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscuelaApplicationTests {

  @Test
  void contextLoads() {
  }

}
