import { Component } from '@angular/core';

@Component({
  selector: 'app-conversiones',
  imports: [],
  templateUrl: './conversiones.component.html',
  styleUrl: './conversiones.component.css'
})
export class ConversionesComponent {

}
