export class Evento {

    idEvento : number = 0;
    nombreEvento : string ='';
    fechaEvento : Date = new Date();
    duracionEvento : number = 0;

}
