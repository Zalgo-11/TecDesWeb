import { Evento } from './evento';

describe('Evento', () => {
  it('should create an instance', () => {
    expect(new Evento()).toBeTruthy();
  });
});
