export class Categoria {
  id:number = 0;
  nombreCategoria:string='';
  descripcionCategoria:string ='';
}
